package com.analisasibernews.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL

private const val SITE_URL = "https://analisasibernews.com"
private const val POSTS_API = "$SITE_URL/wp-json/wp/v2/posts?per_page=30&_embed"

data class NewsItem(
    val id: Int,
    val title: String,
    val excerpt: String,
    val link: String,
    val image: String,
    val date: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ABNApp(onOpen = { url ->
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ABNApp(onOpen: (String) -> Unit) {
    val navy = Color(0xFF123B70)
    val red = Color(0xFFC82032)
    var news by remember { mutableStateOf<List<NewsItem>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var search by remember { mutableStateOf("") }
    var refreshKey by remember { mutableIntStateOf(0) }

    suspend fun loadNews() {
        loading = true
        error = null
        try {
            news = fetchNews()
        } catch (e: Exception) {
            error = "Berita belum dapat dimuat. Periksa koneksi internet atau REST API website."
        } finally {
            loading = false
        }
    }

    LaunchedEffect(refreshKey) { loadNews() }

    MaterialTheme(colorScheme = lightColorScheme(primary = navy, secondary = red)) {
        Scaffold(
            topBar = {
                Column(Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 14.dp, vertical = 12.dp)) {
                    Image(
                        painter = painterResource(id = R.drawable.abn_logo),
                        contentDescription = "Logo resmi AnalisasiberNews.com",
                        modifier = Modifier.fillMaxWidth().height(82.dp),
                        contentScale = ContentScale.Fit
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = search,
                        onValueChange = { search = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        placeholder = { Text("Cari berita...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Cari") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color.White,
                            unfocusedContainerColor = Color.White,
                            focusedBorderColor = Color.White,
                            unfocusedBorderColor = Color.White
                        )
                    )
                }
            },
            floatingActionButton = {
                FloatingActionButton(onClick = { refreshKey++ }, containerColor = red) {
                    Icon(Icons.Default.Refresh, contentDescription = "Muat ulang", tint = Color.White)
                }
            }
        ) { padding ->
            Column(Modifier.padding(padding).fillMaxSize().background(Color(0xFFF5F7FA))) {
                Row(
                    Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("BERITA TERBARU", color = navy, fontWeight = FontWeight.ExtraBold)
                    Text("ANALISASIBERNEWS.COM", color = Color.Gray, fontSize = 10.sp)
                }
                when {
                    loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = navy) }
                    error != null -> Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(error!!, color = Color.DarkGray)
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = { refreshKey++ }) { Text("Coba lagi") }
                    }
                    else -> {
                        val filtered = news.filter {
                            it.title.contains(search, ignoreCase = true) || it.excerpt.contains(search, ignoreCase = true)
                        }
                        if (filtered.isEmpty()) {
                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Belum ada berita yang sesuai.") }
                        } else {
                            LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                items(filtered, key = { it.id }) { item ->
                                    Card(
                                        modifier = Modifier.fillMaxWidth().clickable { onOpen(item.link) },
                                        shape = RoundedCornerShape(14.dp),
                                        colors = CardDefaults.cardColors(containerColor = Color.White),
                                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                                    ) {
                                        Column {
                                            if (item.image.isNotBlank()) {
                                                AsyncImage(
                                                    model = item.image,
                                                    contentDescription = item.title,
                                                    modifier = Modifier.fillMaxWidth().height(190.dp).clip(RoundedCornerShape(topStart = 14.dp, topEnd = 14.dp))
                                                )
                                            }
                                            Column(Modifier.padding(14.dp)) {
                                                Text(item.title, color = Color(0xFF202833), fontWeight = FontWeight.Bold, fontSize = 17.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                                                Spacer(Modifier.height(7.dp))
                                                Text(item.excerpt, color = Color(0xFF596575), fontSize = 13.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                                                Spacer(Modifier.height(9.dp))
                                                Text("Baca selengkapnya  →", color = red, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private suspend fun fetchNews(): List<NewsItem> = withContext(Dispatchers.IO) {
    val connection = (URL(POSTS_API).openConnection() as HttpURLConnection).apply {
        requestMethod = "GET"
        connectTimeout = 15000
        readTimeout = 20000
        setRequestProperty("Accept", "application/json")
    }
    try {
        if (connection.responseCode !in 200..299) error("HTTP ${connection.responseCode}")
        val raw = connection.inputStream.bufferedReader().use { it.readText() }
        val array = JSONArray(raw)
        (0 until array.length()).map { index ->
            val obj = array.getJSONObject(index)
            val embedded = obj.optJSONObject("_embedded")
            val mediaArray = embedded?.optJSONArray("wp:featuredmedia")
            val image = if (mediaArray != null && mediaArray.length() > 0) {
                mediaArray.optJSONObject(0)?.optString("source_url").orEmpty()
            } else ""
            NewsItem(
                id = obj.optInt("id"),
                title = obj.optJSONObject("title")?.optString("rendered").orEmpty().decodeHtml(),
                excerpt = obj.optJSONObject("excerpt")?.optString("rendered").orEmpty().stripHtml().decodeHtml(),
                link = obj.optString("link"),
                image = image,
                date = obj.optString("date")
            )
        }
    } finally {
        connection.disconnect()
    }
}

private fun String.stripHtml(): String = replace(Regex("<[^>]*>"), " ").replace(Regex("\\s+"), " ").trim()
private fun String.decodeHtml(): String = android.text.Html.fromHtml(this, android.text.Html.FROM_HTML_MODE_LEGACY).toString()
