ABN NEWS ANDROID — SOURCE PROJECT v1.0.0

Package ID: com.analisasibernews.app
Nama aplikasi: Analisasiber News
Sumber berita: https://analisasibernews.com/wp-json/wp/v2/posts?per_page=30&_embed

CARA MEMBUKA:
1. Instal Android Studio versi stabil.
2. Ekstrak ZIP ini.
3. Android Studio > Open > pilih folder ABN-News-Android.
4. Tunggu Gradle Sync selesai dan izinkan Android Studio mengunduh dependency.
5. Hubungkan ponsel Android dengan USB (USB debugging aktif) atau buat emulator.
6. Tekan Run untuk memasang aplikasi uji.

MEMBUAT APK:
Android Studio > Build > Build Bundle(s) / APK(s) > Build APK(s).
APK debug akan tersedia di app/build/outputs/apk/debug/app-debug.apk.

FITUR AWAL:
- Mengambil berita terbaru dari WordPress REST API publik.
- Menampilkan judul, ringkasan, gambar unggulan.
- Pencarian judul/ringkasan.
- Membuka artikel lengkap di browser.
- Tampilan merah, biru, putih.

PENTING:
- Ini adalah SOURCE PROJECT, bukan APK yang sudah ditandatangani atau siap Play Store.
- Notifikasi push Firebase belum diaktifkan. Untuk itu diperlukan Firebase project, google-services.json, dan konfigurasi server/plugin pengirim notifikasi.
- REST API website utama harus dapat diakses publik.
- Tombol refresh dan error retry masih perlu disempurnakan pada iterasi berikutnya.
- Pastikan domain dan konten WordPress sudah benar sebelum rilis.

BUILD APK TANPA LAPTOP (GITHUB ACTIONS):
1. Buat akun GitHub jika belum punya: https://github.com
2. Buat repository baru bernama abn-news-android. Pilih Private jika ingin source tidak publik.
3. Di browser HP, buka repository > Add file > Upload files.
4. Unggah seluruh isi folder proyek, termasuk folder tersembunyi .github/workflows/build-apk.yml.
   Pastikan struktur root repository langsung berisi settings.gradle.kts, build.gradle.kts, folder app, dan .github.
5. Tekan Commit changes.
6. Buka tab Actions > Build ABN News APK.
7. Jika workflow belum berjalan otomatis, pilih Run workflow.
8. Tunggu sampai job selesai dengan tanda hijau.
9. Buka hasil run > bagian Artifacts > unduh ABN-News-debug-APK.
10. Ekstrak ZIP artifact dan instal app-debug.apk di HP.

Catatan:
- Build cloud memerlukan koneksi internet dan akun GitHub.
- APK debug untuk pengujian, bukan paket rilis Play Store.
- Jangan pernah memasukkan password WordPress atau kunci rahasia ke repository.
